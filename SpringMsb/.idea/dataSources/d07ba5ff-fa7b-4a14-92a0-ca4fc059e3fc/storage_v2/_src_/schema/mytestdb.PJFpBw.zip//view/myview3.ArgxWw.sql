create definer = root@localhost view myview3 as
select `e`.`empno`  AS `empno`,
       `e`.`ename`  AS `ename`,
       `e`.`sal`    AS `sal`,
       `d`.`deptno` AS `deptno`,
       `d`.`dname`  AS `dname`
from (`mytestdb`.`emp` `e` join `mytestdb`.`dept` `d` on ((`e`.`deptno` = `d`.`deptno`)))
where (`e`.`sal` > 2000);

