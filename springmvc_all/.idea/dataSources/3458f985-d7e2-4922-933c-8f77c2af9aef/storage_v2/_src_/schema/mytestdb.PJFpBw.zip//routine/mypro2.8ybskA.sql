create
    definer = root@localhost procedure mypro2(IN name varchar(10), OUT num int(3))
begin
	if name is null or name="" then 
		select * from emp;
	else 
		select * from emp where ename like concat("%",name,"%");
	end if;
	select found_rows() into num;
end;

