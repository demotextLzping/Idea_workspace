create definer = root@localhost view myview2 as
select `mytestdb`.`emp`.`empno`  AS `empno`,
       `mytestdb`.`emp`.`ename`  AS `ename`,
       `mytestdb`.`emp`.`job`    AS `job`,
       `mytestdb`.`emp`.`deptno` AS `deptno`
from `mytestdb`.`emp`
where (`mytestdb`.`emp`.`deptno` = 20);

