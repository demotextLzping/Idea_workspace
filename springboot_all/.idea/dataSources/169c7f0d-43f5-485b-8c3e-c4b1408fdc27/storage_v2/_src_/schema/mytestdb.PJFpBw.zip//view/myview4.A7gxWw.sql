create definer = root@localhost view myview4 as
select `myview3`.`empno`  AS `empno`,
       `myview3`.`ename`  AS `ename`,
       `myview3`.`sal`    AS `sal`,
       `myview3`.`deptno` AS `deptno`,
       `myview3`.`dname`  AS `dname`
from `mytestdb`.`myview3`
where (`myview3`.`deptno` = 20);

